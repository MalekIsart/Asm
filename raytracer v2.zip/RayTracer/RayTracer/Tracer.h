#pragma once

#include "Background.h"
#include "Sphere.h"

struct Tracer
{
	Background background;
	// scene
	Sphere sphere{ { 0.f, 0.f, 2.f }, 1.f };
	
	// renvoi la couleur intersectee par le rayon
	// ici methode de Appel
	vec3 trace(const Ray& ray)
	{
		// calcul de la couleur du background pour ce pixel
		color col = background.Get(ray.direction);
		if (sphere.intersect(ray) > 0.f) {
			col = { 1.f, 0.f, 1.f };
		}
		return col;
	}
};