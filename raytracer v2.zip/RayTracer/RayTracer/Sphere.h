#pragma once

#include "Ray.h"

struct Sphere
{
	vec3 position;
	float radius;

	// retourne la distance d'intersection (t) si le discriminant est positif
	// sinon retourne une valeur negative (quelconque)
	float intersect(const Ray& ray) const
	{
		vec3 diff = ray.origin - position;
		float a = diff.dot(diff);
		vec3 v = ray.direction;
		v.normalize();
		float b = diff.dot(v); 
		float c = a - radius * radius;
		float t = b*b - c;
		if (t >= 0.f)
			t = -b - sqrtf(t);
		return t;
	}
};