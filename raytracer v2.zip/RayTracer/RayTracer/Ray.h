#pragma once

#include "vec3.h"

struct Ray
{
	vec3 origin;
	float tmin;
	vec3 direction;
	float tmax;

	// calcul la position d'un point (intersection)
	// en fonction d'un parametre de distance
	inline vec3 evaluate(const float t) const {
		return origin + direction * t;
	}
};